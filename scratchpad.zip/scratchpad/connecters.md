# connectors/

Data integration packages that pull from external sources and upsert into Postgres. Each connector is a standalone npm package with a `sync()` function and a `cli.ts` entry point for ECS invocation. All use `runSync()` from `@lp-ai/lib-db` to record results in the `sync_runs` table.

## Connectors

### aplos/ — Financial Data
Syncs bank accounts, funds, and transactions from the Aplos nonprofit accounting system.
- `aplos-client.ts` — RSA-encrypted OAuth token auth with caching
- `sync-accounts.ts`, `sync-funds.ts`, `sync-transactions.ts` — upsert each data type
- Writes to: `finance_snapshots`

### google-sheets/ — Core Org Data (15 sync modules)
The largest connector — syncs students, attendance, certifications, competencies, employment, postsecondary, enrollment, and financials from 12+ Google Sheets.
- `sheets-client.ts` — Google Sheets API wrapper
- `parse.ts` — Zod-based row validation
- `errors.ts` — `HeaderMismatchError` for schema drift detection
- Individual sync files for each data type (students, attendance, phase outcomes, CRM, etc.)
- Writes to: `students`, `student_phase_outcomes`, `student_certifications`, `student_competencies`, `student_employment`, `student_postsecondary`, `attendance_records`, `enrollment_snapshots`, `finance_snapshots`, `entity_aliases`

### notion/ — Meeting Transcripts & Documents
Syncs Notion pages and databases into `document_chunks` for vector search.
- `notion-client.ts` — Notion API wrapper
- `block-walker.ts` — Recursive Notion block traversal (paragraphs, headings, lists, code)
- `chunker.ts` — Splits content into embedding-sized chunks
- `sync-meetings.ts`, `sync-databases.ts` — sync entry points
- Writes to: `document_chunks`

### google-drive/, slack/, bigquery/, roam/ — Skeletons
Return `status: 'noop'` — implementations pending.

## Shared Pattern
```
sync() → runSync('name', async () => {
  // upsert records by stable sourceId
  // after all upserts: delete stale rows
  return { status: 'ok', recordsUpserted: n }
})
```
Never truncate before insert — always upsert + stale cleanup after.
